<?php $a=4;
$b=8;
echo $a/$b; ?>
